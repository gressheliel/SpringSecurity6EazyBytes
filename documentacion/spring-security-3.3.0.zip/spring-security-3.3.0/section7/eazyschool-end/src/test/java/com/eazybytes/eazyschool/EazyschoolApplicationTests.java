package com.eazybytes.eazyschool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EazyschoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
